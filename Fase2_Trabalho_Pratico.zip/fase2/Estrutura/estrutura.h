#ifndef GENERATOR_ESTRUTURA_H
#define GENERATOR_ESTRUTURA_H


struct vertices {
    float x;
    float y;
    float z;
};


#endif //GENERATOR_ESTRUTURA_H
